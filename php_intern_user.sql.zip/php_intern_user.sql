-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Авг 03 2021 г., 19:41
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `g99999ep_bd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `php_intern_user`
--
-- Создание: Авг 02 2021 г., 15:41
-- Последнее обновление: Авг 03 2021 г., 15:10
--

DROP TABLE IF EXISTS `php_intern_user`;
CREATE TABLE `php_intern_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `network` varchar(32) NOT NULL,
  `uid` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `php_intern_user`
--

INSERT INTO `php_intern_user` (`id`, `name`, `email`, `password`, `network`, `uid`) VALUES
(17, 'Andrey', 'ecc77dfb3d53cbe6a6c94c4a4e32c5b4', '85064efb60a9601805dcea56ec5402f7', '', ''),
(43, 'Nikita', 'b48d680d823c1d7da7facd7166dd826d', '96e79218965eb72c92a549dd5a330112', 'google', '3f07b3ee703d7737f457dad85a762dfa');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `php_intern_user`
--
ALTER TABLE `php_intern_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `php_intern_user`
--
ALTER TABLE `php_intern_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
